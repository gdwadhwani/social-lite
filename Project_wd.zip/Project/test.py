__author__ = 'gordon'
import math
# distance
u_address = raw_input("address:").split()
x1 = int(u_address[0])
y1 = int(u_address[1])
e_address = (3,4)
x2 = e_address[0]
y2 = e_address[1]
distance = math.hypot(x2 - x1, y2 - y1)

'''
#alternative easy way
u_city=e_city
'''

u_interests = ["sport","ball"]


