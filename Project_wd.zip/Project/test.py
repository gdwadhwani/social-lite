__author__ = 'gordon'
import nltk
from nltk.tokenize import *
import re

a=""
print len(a)